create definer = root@localhost trigger remove_zombie_users
    after update
    on users
    for each row
BEGIN
IF NEW.phoneNumber='1 2 3' THEN
#	UPDATE users SET NEW.ADDRESSACTUAL_prim = NULL;	
#	DELETE FROM addresses WHERE addresses.prim = NEW.ADDRESSACTUAL_prim;
#	UPDATE users SET users.lastname ='new_zombie_1' ; 
	DELETE FROM users WHERE phoneNumber='1 2 3';
#	UPDATE users SET users.lastname = NULL;

 END IF;
END;

